function AddPath(probName)
    if ~isdeployed
        cd(fileparts(mfilename('fullpath')));
        addpath(genpath(cd));
        
        if strcmp(probName,'LargeScaleCEC2010Benchmark')
            addpath('./LargeScaleCEC2010Benchmark');
            addpath('./LargeScaleCEC2010Benchmark/datafiles');    
        end
        if strcmp(probName,'LargeScaleCEC2013Benchmark')
            addpath('./LargeScaleCEC2013Benchmark');
            addpath('./LargeScaleCEC2013Benchmark/datafiles');   
        end
    end
end