function popFit = EvaluateFit(fhd, pop)
    global prob alg;
    
    [NP, ~] = size(pop);
    popFit = NaN(NP, prob.objN);

    for i=1 : NP     
        popFit(i,:) = feval(fhd, pop(i,:), prob.fNum);
        alg.fEvalNum = alg.fEvalNum + 1;
        
        UpdateBestGlobal(pop(i,:), popFit(i,:));
        
        SetOutputValues(alg.bestGlobal);   
        
        IsTerminate();
        if alg.isTerminate
            return;
        end
    end
end


function UpdateBestGlobal(varargin)
    global prob alg;    
    
    if isempty(alg.bestGlobal)
        x =  varargin{1}(1, :);
        f = varargin{2}(1, :);
        alg.bestGlobal.x = x;
        alg.bestGlobal.f = f;
    end
    for index = 1 : size(varargin{1}, 1)
        x = varargin{1}(index, :);
        f = varargin{2}(index, :);
        isBetter = IsBetter(repmat(f, size(alg.bestGlobal.f, 1), 1), alg.bestGlobal.f, 2, prob.betterSign);
        if prob.objN == 1 && any(isBetter == 1) 
            alg.bestGlobal.x = x;
            alg.bestGlobal.f = f;
        elseif prob.objN > 1 && (any(isBetter == 1) || sum(isBetter==0, 1) == size(isBetter, 1))
            alg.bestGlobal.x = alg.bestGlobal.x(isBetter==0 | isBetter==-1, :);
            alg.bestGlobal.f = alg.bestGlobal.f(isBetter==0 | isBetter==-1, :);
            alg.bestGlobal.x = [alg.bestGlobal.x; x];
            alg.bestGlobal.f = [alg.bestGlobal.f; f];
        end        
    end
end

function SetOutputValues(varargin)
    global prob alg;
    
    bestFit =varargin{1}.f;
    if isempty(alg.outputValues)
        outputValuesN = min([1001 alg.Max_FEs]);
        outputAtFEs = floor(linspace(alg.fEvalNumInitial+1, alg.Max_FEs, outputValuesN));
        outputAtFEs = union(outputAtFEs', alg.mustOutputPoints);
        outputValuesN = numel(outputAtFEs);
        alg.outputValues = nan(outputValuesN, 1+prob.objN);
        alg.outputValues(:,1) = outputAtFEs;
    end
    
    index = find(alg.outputValues(:,1)==alg.fEvalNum,1);
    if ~isempty(index)
        alg.outputValues(index, 2:end) = bestFit;
    end
    if alg.fEvalNum == alg.Max_FEs
        alg.outputValues = alg.outputValues(~isnan(alg.outputValues(:,1)),:);
    end
end

function IsTerminate(varargin)
    global prob alg;
    
    if alg.fEvalNum >= alg.Max_FEs
        alg.isTerminate = 1;
    else
        alg.isTerminate = 0;
    end
end