function OutputResults(benchmarkName, decomposition, runIndex)
    global alg prob;
    
    outputFileDir = strcat('./',benchmarkName, '/OptResult', '/', decomposition, '_', alg.optimizer, '/');
    if ~exist(outputFileDir, 'dir')
        mkdir(outputFileDir);
    end
    outputFileName = strcat(outputFileDir, '/f', num2str(prob.fNum), '_run', num2str(runIndex), '.mresult');
    fid = fopen(outputFileName, 'w');
    fprintf(fid, strcat('%d', repmat('\t%.10E', 1, prob.objN), '\n'), alg.outputValues');
    fclose(fid);
end