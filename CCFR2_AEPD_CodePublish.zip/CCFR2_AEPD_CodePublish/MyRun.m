% This program is implemented by Ming Yang (mingyang@cug.edu.cn).
% The referred paper is as follows. You should refer the following paper if you use the program.
% M. Yang, J. Gao, A. Zhou, C. Li and X. Yao, "Contribution-Based Cooperative Co-Evolution With Adaptive Population Diversity for Large-Scale Global Optimization [Research Frontier]," in IEEE Computational Intelligence Magazine, vol. 18, no. 3, pp. 56-68, Aug. 2023, doi: 10.1109/MCI.2023.3277772.


%This file is the main file of the program. Please run this program as follows.
% MyRun(problemName, functionNum, runIndexStart, runIndexEnd);
% % % problemName: the file name of the benchmark problem, i.e., 'LargeScaleCEC2013Benchmark' or 'LargeScaleCEC2010Benchmark'
% % % functionNum: the serial number of a function in the problems, which is an integer
% % % runIndexStart and runIndexEnd: the values are integers. The program will run runIndexEnd-runIndexStart times.
% Example: MyRun('LargeScaleCEC2013Benchmark', 1, 1,25);
% For the example, the program will run 25 times on the CEC'2013 function f1.

function MyRun(varargin)
    warning off;
    global initial_flag; % the global flag used in test suite

    runsN = 25; % number of independent runs for each function, should be set to 25
    
    benchmarkName = varargin{1};
    if isdeployed
        func_num = str2num(varargin{2});
        runIndexStart = str2num(varargin{3});
        runIndexEnd = str2num(varargin{4});
    else
        func_num = varargin{2};
        runIndexStart = varargin{3};
        runIndexEnd = varargin{4};
    end  
    decompositionMethod = 'ERDG';
    optimizer = 'CMAES';
    
    AddPath(benchmarkName);
    Initialize(benchmarkName, func_num, decompositionMethod,optimizer); 

    for runIndex = runIndexStart : runIndexEnd
        rand('seed', ceil(1 / (runsN +1)* runIndex * (2^32)));
        randn('seed', ceil(1 / (runsN +1)* runIndex * (2^32)));
        initial_flag = 0; % should set the flag to 0 for each run, each function
        CCFR2_AEPD(); 
        OutputResults(benchmarkName, decompositionMethod, runIndex);
    end
end