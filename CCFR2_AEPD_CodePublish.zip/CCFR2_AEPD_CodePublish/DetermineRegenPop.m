function [isRegenPop] = DetermineRegenPop(pop, groupDimIndex)
    global evolState_group groupIndexGlobal;
      
    meanDim= evolState_group{groupIndexGlobal}.meanDim;
    stdDim = evolState_group{groupIndexGlobal}.stdDim;
    meanDim001 = mean(pop(:, groupDimIndex), 1); stdDim001 = std(pop(:, groupDimIndex), 1,1);   
    
    precisionDemand = ones(size(stdDim001)) * 1e-10;

    if isempty(evolState_group{groupIndexGlobal}.threshStdDimInitial)
        evolState_group{groupIndexGlobal}.threshStdDimInitial = min(ones(size(stdDim001)) * 1e-3, stdDim001 * 1e-3); 
    end   
    if isempty(evolState_group{groupIndexGlobal}.unChangeGenNDim)
        evolState_group{groupIndexGlobal}.unChangeGenNDim = zeros(size(meanDim001));
    end
    
    isStagnantDim = false(size(meanDim001));
    if ~isempty(meanDim) 
        for i = 1 : numel(isStagnantDim)
            if meanDim(i)==meanDim001(i) && stdDim(i)==stdDim001(i)
                evolState_group{groupIndexGlobal}.unChangeGenNDim(i) = evolState_group{groupIndexGlobal}.unChangeGenNDim(i) + 1;
                UN = floor(sqrt(numel(pop(:, groupDimIndex(i)))))+1;
                if evolState_group{groupIndexGlobal}.unChangeGenNDim(i) >= UN
                    evolState_group{groupIndexGlobal}.unChangeGenNDim(i) = UN;
                    isStagnantDim(i) = true;
                end
            else
                evolState_group{groupIndexGlobal}.unChangeGenNDim(i) = 0;
            end
        end
    end

    if ~isempty(evolState_group{groupIndexGlobal}.bestIndiLastRegenPop)
        evolState_group{groupIndexGlobal}.threshStdDim = min(evolState_group{groupIndexGlobal}.threshStdDimInitial, ...
                    1e-3 * abs(evolState_group{groupIndexGlobal}.bestIndiLastRegenPop - meanDim001));    
    else
        evolState_group{groupIndexGlobal}.threshStdDim = evolState_group{groupIndexGlobal}.threshStdDimInitial;   
    end
    evolState_group{groupIndexGlobal}.threshStdDim = max(precisionDemand, evolState_group{groupIndexGlobal}.threshStdDim);
    
    isConvergeDim = stdDim001 <= evolState_group{groupIndexGlobal}.threshStdDim;
                                   
    evolState_group{groupIndexGlobal}.regenPopFlagDim = isConvergeDim | isStagnantDim;


    isRegenPop = 0;
    if sum(evolState_group{groupIndexGlobal}.regenPopFlagDim) == numel(isStagnantDim) 
        isRegenPop = 1;
        evolState_group{groupIndexGlobal}.bestIndiLastRegenPop = meanDim001;
    end
   
    evolState_group{groupIndexGlobal}.meanDim = meanDim001;
    evolState_group{groupIndexGlobal}.stdDim = stdDim001;
end