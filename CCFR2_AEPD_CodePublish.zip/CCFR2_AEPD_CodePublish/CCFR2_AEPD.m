function CCFR2_AEPD()
    global prob alg;
    global deltaFitGlobal;

    groups = prob.groups;
    
    groupN = size(groups,1);
    if strcmp(alg.optimizer, 'CMAES')
        pop = [];
    else
        pop = repmat(prob.lb, alg.NP, 1) + (repmat(prob.ub, alg.NP, 1) - repmat(prob.lb, alg.NP, 1)) .* rand(alg.NP, prob.D);
    end
    
    global evolState_group;
    evolState_group = [];
    for i = 1 : groupN
        evolState_group{i}.first = 1;
        evolState_group{i}.bestIndiLastRegenPop = [];
        evolState_group{i}.deltaFitRegenPop = [];
        evolState_group{i}.unChangeGenNDim = [];
        evolState_group{i}.threshStdDimInitial = [];
        evolState_group{i}.regenedPop = 0;
        evolState_group{i}.needRegenPop = 0;
        if strcmp(alg.optimizer, 'CMAES')
            evolState_group{i}.meanDim = [];
            evolState_group{i}.stdDim =  [];
            evolState_group{i}.threshStdDim = []; 
        else
            evolState_group{i}.meanDim = mean(pop(:, groups{i}), 1);
            evolState_group{i}.stdDim =  std(pop(:, groups{i}), 1,1);
            evolState_group{i}.threshStdDim = ones(size(evolState_group{i}.stdDim)) * 1e-3;
        end
    end
    deltaFitGlobal = nan(groupN,1);
    global deltaFitRegenPopGlobal;
    deltaFitRegenPopGlobal = nan(groupN,1);    

    [pop] = EvolveGroup([1:groupN],pop);
    while alg.isTerminate == 0
        if alg.isTerminate==1
            break;
        end
            
        if all(isnan(deltaFitGlobal))
            randT = 1;
            groupsIndex = find(~isnan(deltaFitRegenPopGlobal));
        else
            [maxDeltaFit, ~] = max(deltaFitGlobal);
            mylogical = deltaFitRegenPopGlobal > maxDeltaFit;
            randT = sum(mylogical) / numel(mylogical);
            groupsIndex = find(mylogical);
        end

        if rand < randT     
            [~, groupsIndexSort] = sort(deltaFitRegenPopGlobal(groupsIndex), 'descend');
            groupsIndex = groupsIndex(groupsIndexSort);
        else
            if min(deltaFitGlobal) == max(deltaFitGlobal) 
                groupsIndex = find(~isnan(deltaFitGlobal));
            else
                [~,groupsIndex] = max(deltaFitGlobal);
            end
        end
        
        [pop] = EvolveGroup(groupsIndex, pop);        
    end
end


function [pop] = EvolveGroup(groupsIndex, pop)
    global alg prob;
    global groupIndexGlobal;
    global deltaFitGlobal deltaFitRegenPopGlobal;    
    
    for i = 1 : numel(groupsIndex)
        groupIndexGlobal = groupsIndex(i); 
        CMAES_group(prob.groups{groupIndexGlobal});
        pop = [];
    end
    
    mylogical001 = deltaFitGlobal ~= 0 & ~isnan(deltaFitGlobal);
    mylogical = deltaFitRegenPopGlobal == 0 & ~isnan(deltaFitRegenPopGlobal);
    mylogical002 = deltaFitRegenPopGlobal ~= 0 & ~isnan(deltaFitRegenPopGlobal);
    if any(mylogical002 | mylogical001)
        deltaFitRegenPopGlobal(mylogical) = min([deltaFitGlobal(mylogical001); deltaFitRegenPopGlobal(mylogical002)]) *0.9;
     end 
end