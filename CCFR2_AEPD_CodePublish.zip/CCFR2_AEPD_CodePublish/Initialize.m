function Initialize(benchmarkName, func_num, decompositionMethod,optimizer) 
    global prob alg;
    
    [lb001, ub001]=SetProbBound(benchmarkName,func_num);
    D = 1000;
    if strcmp(benchmarkName,'LargeScaleCEC2013Benchmark')==1 && ismember(func_num, [13,14])
        D = 905;
    end
    if strcmp(benchmarkName, 'LargeScaleCEC2013Benchmark')== 1
        mustOutputPoints =[500501, 500501, 500501, 500501, 500501, 500501, 500501, 500501, 500501, 500501, 500501, 500501, 409966, 409966, 500501;...
                                            2998, 2998, 5992, 9832, 9895, 11587, 9814, 19405, 19156, 19879, 19429, 50866, 15187, 16150, 5992;...
                                            2998, 2998, 3996, 5326, 5395, 5905, 5554, 8451, 8812, 8794, 9212, 26980, 7599, 8420, 3996];
    end
    
    groupFilePath = strcat('./',benchmarkName,'/GroupResult/', decompositionMethod);
    groupFile = strcat(groupFilePath, '/f', num2str(func_num), '_groups.mat');
    load(groupFile, '-mat', 'groups', 'fEvalNum');    

    prob.betterSign = -1; % -1 for minimization, 1 for maximization
    prob.D = D;    
    prob.fhd = str2func('benchmark_func'); %fitness function
    prob.fNum = func_num;
    prob.objN = 1; % 1 for single-objective optimization
    prob.lb = lb001*ones(1,D); prob.ub = ub001*ones(1,D);
    prob.groups = groups;
    
    alg.outputValues = [];
    alg.fEvalNumInitial = fEvalNum;
    alg.fEvalNum = alg.fEvalNumInitial;
    alg.bestGlobal = [];
    alg.NP = [];    
    alg.Max_FEs = 3E6;
    alg.mustOutputPoints = [];    
    alg.optimizer = optimizer;   
end